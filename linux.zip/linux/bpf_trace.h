/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __LINUX_BPF_TRACE_H__
#define __LINUX_BPF_TRACE_H__

#include <trace/events/xdp.h>

#endif /* __LINUX_BPF_TRACE_H__ */
