/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _LINUX_BTRFS_H
#define _LINUX_BTRFS_H

#include <uapi/linux/btrfs.h>

#endif /* _LINUX_BTRFS_H */
